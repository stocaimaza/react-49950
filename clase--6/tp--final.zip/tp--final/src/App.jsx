import React from 'react';
import ItemCount from './componentes/ItemCount/ItemCount';
import NavBar from './componentes/NavBar/NavBar';
import ItemListContainer from './componentes/ItemListContainer/ItemListContainer';


const App = () => {
  return (
    <>
      <NavBar/>
      <ItemListContainer greeting="Hola Comisión"/>
    </>
  )
}

export default App