import './CartWidget.css';

const CartWidget = () => {
  return (
    <div>
        <img className='imgCarrito' src="./img/carrito.png" alt="Carrito" />
        <strong> 3 </strong>
    </div>
  )
}

export default CartWidget